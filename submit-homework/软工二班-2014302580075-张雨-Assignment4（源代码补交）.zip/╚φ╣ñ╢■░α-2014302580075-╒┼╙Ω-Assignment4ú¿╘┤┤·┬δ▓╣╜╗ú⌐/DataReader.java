package ����;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DataReader {
	private ArrayList<String> data=new ArrayList<>();
	public ArrayList<String> getData() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");//
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery("select * from ѧ��_professor_info");
		while (resultSet.next()) {
			String professorInfo=resultSet.getString("ID")+ resultSet.getString("Name")+
					resultSet.getString("PhoneNumber")+ resultSet.getString("Email")+
					resultSet.getString("Education") +resultSet.getString("Introduction") +
					resultSet.getString("ResearchInterests") + resultSet.getString("Publications");
			data.add(professorInfo);
		}
		return data;
	}
}
