package ����;

public class Search {
	
	public static void main(String[] args) throws Exception {
		SearchGUI searchGUI=new SearchGUI();
		searchGUI.run();
		
	}

}
