package ����;

public class ProfessorInfo {
	
	private  String ID="";
	private String Name="";
	private String PhoneNumber="";
	private String Email="";
	private String Education="";
	private String Introduction="";
	private String ResearchInterests="";
	private String Publications="";
	public void setProfessorInfo(String ID,String Name,String PhoneNumber,String Email,
				String Education,String Introduction,String ResearchInterests,String Publications) {
		this.ID=ID;
		this.Name=Name;
		this.PhoneNumber=PhoneNumber;
		this.Email=Email;
		this.Education=Education;
		this.Introduction=Introduction;
		this.ResearchInterests=ResearchInterests;
		this.Publications=Publications;
	}

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getEducation() {
		return Education;
	}
	public void setEducation(String education) {
		Education = education;
	}
	public String getIntroduction() {
		return Introduction;
	}
	public void setIntroduction(String introduction) {
		Introduction = introduction;
	}
	public String getResearchInterests() {
		return ResearchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		ResearchInterests = researchInterests;
	}
	public String getPublications() {
		return Publications;
	}
	public void setPublications(String publications) {
		Publications = publications;
	}
	
	
}
