package ����;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class SearchGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JButton btnSearch = new JButton("Search");
	private JScrollPane scrollPane = new JScrollPane();
	private JTextArea textArea = new JTextArea();
	
	public void run() throws Exception {
		this.setVisible(true);
		//�����ݿ����Ϣ����professorInfos��
		ArrayList<ProfessorInfo> professorInfos=new ArrayList<>();
		Class.forName("com.mysql.jdbc.Driver");
		
		java.sql.Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");//
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery("select * from ѧ��_professor_info");
		while (resultSet.next()) {
			ProfessorInfo professorInfo=new ProfessorInfo();
			professorInfo.setProfessorInfo(resultSet.getString("ID"), resultSet.getString("Name"), 
					resultSet.getString("PhoneNumber"), resultSet.getString("Email"),
					resultSet.getString("Education") ,resultSet.getString("Introduction") ,
					resultSet.getString("ResearchInterests") , resultSet.getString("Publications"));
			professorInfos.add(professorInfo);
		}
		//���Ӱ�ť�¼�����
		btnSearch.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent arg0) {
				
				try {
					textArea.setText("");
					int[] professorOrder;
					KeywordsMatcher keywordsMatcher=new KeywordsMatcher();
					Sorter sorter=new Sorter();
					professorOrder=sorter.sort(keywordsMatcher.getTF(textField.getText()));
					textArea.append("������������Ĺؼ��ʣ�"+textField.getText()+"���������\n");
						for (int i = 0; i < professorOrder.length; i++) {
							if (professorOrder[i]>0) {//
								ProfessorInfo pInfo=new ProfessorInfo();
								pInfo=professorInfos.get(professorOrder[i]);
//								System.out.println(pInfo.getID()+"\n"+pInfo.getName()+"\n"+pInfo.getPhoneNumber()+"\n"+pInfo.getEmail()
//										+"\n"+pInfo.getEducation()+"\n"+pInfo.getIntroduction()+"\n"+pInfo.getResearchInterests()+"\n"+pInfo.getPublications());
								textArea.append("���ݿ�ID:"+pInfo.getID()+"\n"+"������"+pInfo.getName()+"\n"+"�绰�봫����룺"+pInfo.getPhoneNumber()+"\n"+"�ʼ���ַ��"+pInfo.getEmail()
								+"\n"+"����������"+pInfo.getEducation()+"\n"+"���˼�飺"+pInfo.getIntroduction()+"\n"+"�о�����"+pInfo.getResearchInterests()+"\n"+"���˳����"+pInfo.getPublications());
								textArea.append("\n.............�ָ���.................................................................�ָ���...................................................."
										+ ".............�ָ���.................................................................�ָ���....................................................\n");
							
							}
					}
					
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			
			}
		
		});
	}
	/**
	 * Create the frame.
	 */
	public SearchGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 518, 404);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(5, 5, 388, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		btnSearch.setBounds(403, 4, 89, 30);
		contentPane.add(btnSearch);
		
		
		scrollPane.setBounds(5, 45, 487, 310);
		contentPane.add(scrollPane);
		
		
		scrollPane.setViewportView(textArea);
	}
}
