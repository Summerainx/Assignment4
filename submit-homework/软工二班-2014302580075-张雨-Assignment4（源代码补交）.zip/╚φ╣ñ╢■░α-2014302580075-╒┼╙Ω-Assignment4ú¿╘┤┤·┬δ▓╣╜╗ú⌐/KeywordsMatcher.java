package ����;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KeywordsMatcher {
	private ArrayList<String> professors=new ArrayList<>();
	public double[] getTF(String keywords) throws Exception {
		DataReader dataReader=new DataReader();
		Pattern wordpattern=Pattern.compile("\\w+");
		professors=dataReader.getData();
		double[] TF=new double[professors.size()];
		for (int i = 0; i < professors.size(); i++) {
			double keywordsNumber=0.0;
			ArrayList<String> words=new ArrayList<>();
			Matcher matcher=wordpattern.matcher(professors.get(i));
			while (matcher.find()) {
				words.add(matcher.group());
			}
			for (String word : words) {
				if (word.equalsIgnoreCase(keywords)) {
					keywordsNumber++;
				}
			}
			TF[i]=keywordsNumber/words.size();
		}
		
//		for (int i = 0; i < TF.length; i++) {
//			System.out.println(i+"TF"+TF[i]);
//		}
		return TF;
	}
	
}
