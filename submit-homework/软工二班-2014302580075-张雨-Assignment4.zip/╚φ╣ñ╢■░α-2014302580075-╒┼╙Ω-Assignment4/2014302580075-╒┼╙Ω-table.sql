/*
Navicat MySQL Data Transfer

Source Server         : Test
Source Server Version : 50546
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50546
File Encoding         : 65001

Date: 2015-11-17 22:18:31
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for 2014302580075_professor_info
-- ----------------------------
DROP TABLE IF EXISTS `2014302580075_professor_info`;
CREATE TABLE `2014302580075_professor_info` (
  `ID` int(10) DEFAULT NULL,
  `Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(200) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Education` varchar(5000) NOT NULL,
  `Introduction` varchar(5000) NOT NULL,
  `ResearchInterests` varchar(5000) NOT NULL,
  `Publications` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
